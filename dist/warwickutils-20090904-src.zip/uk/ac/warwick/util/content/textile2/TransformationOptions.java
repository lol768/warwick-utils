package uk.ac.warwick.util.content.textile2;

public enum TransformationOptions {
	
	alwaysUseAlternativeMp3Player

}
