package uk.ac.warwick.util.content.textile2;

public enum TransformationOptions {
	
	alwaysUseAlternativeMp3Player,
	useNativeAudioVideoElements //HTML5 for audio and video where available

}
