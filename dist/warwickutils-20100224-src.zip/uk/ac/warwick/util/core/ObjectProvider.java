package uk.ac.warwick.util.core;

public interface ObjectProvider<T> {
    
    T newInstance();

}
