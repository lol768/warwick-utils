package uk.ac.warwick.util.httpclient;

import org.apache.commons.httpclient.HttpClient;

public interface HttpClientFactory {
    
    public HttpClient getClient();

}
