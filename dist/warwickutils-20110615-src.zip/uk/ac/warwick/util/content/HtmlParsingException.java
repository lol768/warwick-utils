package uk.ac.warwick.util.content;

public class HtmlParsingException extends Exception {

    private static final long serialVersionUID = -3330729096556647407L;

    public HtmlParsingException(String message, Throwable cause) {
        super(message, cause);
    }

}
