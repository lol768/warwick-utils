package uk.ac.warwick.util.content.textile2.jruby;

public interface TextileService {
    String textileToHtml(String textile, boolean hard_breaks);
}
