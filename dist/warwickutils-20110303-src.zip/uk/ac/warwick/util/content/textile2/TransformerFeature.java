package uk.ac.warwick.util.content.textile2;

public enum TransformerFeature {
	
	textilise,
	backslashes,
	media,
	latex,
	removeJsLinks,
	noFollowLinks

}
