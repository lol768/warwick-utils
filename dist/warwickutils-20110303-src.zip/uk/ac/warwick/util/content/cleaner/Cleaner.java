package uk.ac.warwick.util.content.cleaner;

public interface Cleaner {
    
    String clean(final String input);

}
