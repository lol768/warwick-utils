package uk.ac.warwick.util.httpclient.httpclient4;

import org.apache.http.client.HttpClient;

public interface HttpClientFactory {
    
    public HttpClient getClient();

}
