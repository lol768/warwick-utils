package org.codehaus.jackson.map.deser;

/**
 * @deprecated Since 1.9, use {@link org.codehaus.jackson.map.deser.std.PrimitiveArrayDeserializers} instead.
 */
@Deprecated
public class ArrayDeserializers
    extends org.codehaus.jackson.map.deser.std.PrimitiveArrayDeserializers
{
    private ArrayDeserializers() { super(); }
}
